Hamza Faour
101195438
COMP3005
Final Project

--VIDEO LINK--
https://youtu.be/u_bzAQaxl9c

--FOLDER--
1. Diagram-2NF-3NF: ER Model and the 2NF-3NF
2. SQL-DDL: SQL queries and DDL
3. Video: mp4 of the video (also linked above)